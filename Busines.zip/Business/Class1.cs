﻿namespace Business
{
    public class Class1
    {

    }
}