﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Concrete
{
    public class Person
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public int DateOfBirthDay { get; set; }
        public long NationalIdenity {  get; set; }


    }
}
